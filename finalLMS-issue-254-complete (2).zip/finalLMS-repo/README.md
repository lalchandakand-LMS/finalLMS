# Alom's English Center LMS

Laravel 12 LMS application targeting PHP 8.3+ and MySQL/MariaDB. The repository was missing its runtime directories; they have been restored and the app boots on Laravel 12.

## Local development

```bash
composer install
cp deployment/.env.example .env
```

For local use, set `APP_ENV=local`, `APP_DEBUG=true`, `APP_INSTALLED=true`, `DB_CONNECTION=sqlite`, and `MAIL_MAILER=log` in `.env`, then run:

```bash
php artisan key:generate
php artisan migrate --seed
php artisan serve
```

The local/testing seeder creates `admin@lms.test`, `teacher@lms.test`, and `student@lms.test` with password `password`. These accounts are local-only; production seeding does not create them. See [cPanel deployment](deployment/cpanel.md) for production setup.

## Implemented

- Student registration, email verification, profile updates, and Twilio phone OTP integration
- Admin, branch manager, accountant, teacher, and student role foundations; role middleware and protected routes
- Branch managers are assigned one branch and can create/update only that branch's batches; accountants can access the invoice ledger without admin payment-review or user-management access
- Courses, lessons, course enrollment, certificates, and manual payment review
- Admin-managed course combos with public package pages, fixed combo pricing, manual payment review, immutable purchased-course snapshots, and atomic enrollment into every included course after approval.
- Student web sign-in with SMS verification for the first browser device, administrator approval for additional devices, one approved browser device at a time, and server-side invalidation of revoked browser sessions.
- Branch and batch create/read/update/delete controls; teacher-scoped batch views
- Batch enrollment associations, teacher attendance entry, and student-private attendance history
- Batch assignments, one submission per enrolled student, teacher grading/feedback, and private PDF/DOC/DOCX/JPG/PNG attachment submissions (10 MB limit)
- Batch live-class scheduling with teacher ownership checks, student enrollment filtering, and time-windowed meeting-link visibility
- Batch multiple-choice examinations with one-attempt enforcement, timed attempts, automatic scoring, student result views, teacher-only paginated result reports, reusable teacher-owned question banks, and randomized question selection
- Public published-course catalog and slug URLs; lesson bodies require enrollment except preview lessons
- Lesson progress tracking; certificates require every course lesson completed
- Batch seat reservation for pending payments, unique transaction references, and last-admin protection
- SEO metadata, consent-gated GA4/GTM/Meta Pixel tags, and consent-based queued bulk SMS
- Admin homepage, payment, user, course, and settings controls, including a branded responsive operations dashboard
- Secure first-run cPanel web installer with database connection checks, empty-database guard, random app key, first-admin creation, and installation gate
- Administrator assignment of students to active branches, with inactive-branch validation
- Student invoices with fixed/percentage discounts (including student-specific scholarship adjustments), partial/installment receipts, and net outstanding balance tracking
- Refund request ledger tied to original receipts, refund caps, admin approval/rejection, and invoice balance recalculation
- Expense management with create/edit/delete, category and date filters, branch-scoped accountant access, and head-office expenses
- Finance reports with payment-method and expense-category summaries, date filters, current outstanding balance, approved refund totals, printable ledger, and net cash movement (collections minus refunds and expenses)
- Admin activity log for successful authenticated changes, with user/action/route/IP filters
- Public About, Contact, FAQ, and published Blog/News pages; admin-managed article drafts, publishing, SEO metadata, and cover images
- Section-based homepage Website Builder with up to 12 editable text/image/button sections; user content is escaped and does not accept arbitrary scripts
- Admin Media Library for validated image, document, and video uploads with protected deletion of assets referenced by articles
- Signed, application-key-protected database + uploaded-media + private assignment-attachment backup archives; administrator restore requires current password and explicit confirmation, with schema compatibility checks
- English/Bangla session-based language selector and expanded JSON translation catalogue for core navigation, authentication, course, profile, exam, live-class, and CMS screens

## Not yet complete

This remains an actively developed LMS and is not yet a fully validated commercial release. Remaining work includes complete Bangla translation coverage across every screen, richer drag-and-drop page design and reusable page templates, deeper branch-scoped enrollment, transfer, and teacher-assignment workflows beyond the current student-to-branch assignment, official bKash/Nagad/SSLCommerz API integration with verified callbacks, automated scheduled off-site backups and tested disaster recovery, the Admin Update Center and safe in-app release activation/rollback, and real cPanel staging validation of the installer and deployment process. The current backup/restore feature is administrator-triggered and should be tested on a staging database before production use. Activity logging covers successful authenticated write requests; it is not yet a full audit trail for reads, login attempts, failed actions, or field-level changes. SMS/email delivery requires real provider credentials.

## AI developer handoff and project memory

To continue this repository in ChatGPT, Google AI Studio, or with another developer, read these project records first:

1. [AI Studio Handoff](docs/AI_STUDIO_HANDOFF.md) — complete product context, technical architecture, module scope, security rules and copy/paste continuation instructions.
2. [Project Status](docs/PROJECT_STATUS.md) — current known workstreams, priorities, blockers and release status.
3. [Owner Decision Log](docs/DECISION_LOG.md) — approved product decisions and architecture rules.

**Current panel decision:** five operational panels — one unified Admin Panel (no separate Super Admin), a separate branch-scoped Branch Panel, Teacher Panel, Student Panel and Guardian Panel. Older issue descriptions may conflict; follow the latest owner decision recorded in the Decision Log.

When code changes, update the handoff/status/decision documents in the same PR where practical. Record branch, PR, exact commit SHA, files changed, tests and CI evidence, known limitations, next step, and whether changes are merged or deployed. Documentation is not proof of implementation: always inspect source and fresh test results. The owner has authorized autonomous feature-branch/PR work and safe merges to main when the complete diff is reviewed, exact-head CI/CodeQL pass, dependencies/conflicts are checked, and the change is safe. Do not ask again for routine PR merge approval. Production deployment, live payment activation, and irreversible production data migrations remain separate safety gates: proceed only when the scope, backup, rollback path, and target environment are verifiably safe; otherwise stop and report the specific blocker.

## First production administrator

Student registration only creates student accounts. After configuring the production database, create and verify the first admin through Tinker using a unique password:

```bash
php artisan tinker
```

```php
$admin = App\Models\User::create([
	'name' => 'Site Administrator',
	'email' => 'your-admin@your-domain.example',
	'password' => 'replace-with-a-unique-strong-password',
	'role' => 'admin',
]);
$admin->markEmailAsVerified();
```

Replace the example values before running the commands. Passwords are hashed by the user model.

## Tests and assets

```bash
vendor/bin/phpunit
npm ci
npm run build
```

The GitHub Actions workflow runs tests on PHP 8.3 with MySQL and builds Vite assets. Production does not require Node after `public/build` is generated.
